package com.smart.api;

import static org.junit.Assert.*;

import java.util.Calendar;

import org.junit.Before;
import org.junit.Test;

import com.smart.model.SmartCard;
import com.smart.model.Station;
import com.smart.model.Trip;
import com.smart.service.MSCS;

public class ReportsTest{

	@Before
	public void setData(){

		SmartCard smartCard = new SmartCard(12, true, false, 123456);
		MSCS.getCardMap().put(smartCard.getCardNo(), smartCard);
		smartCard = new SmartCard(12, true, false, 1234567);
		MSCS.getCardMap().put(smartCard.getCardNo(), smartCard);
		smartCard = new SmartCard(5, true, false, 1234568);
		MSCS.getCardMap().put(smartCard.getCardNo(), smartCard);
		smartCard = new SmartCard(6, true, false, 1234569);
		MSCS.getCardMap().put(smartCard.getCardNo(), smartCard);
		smartCard = new SmartCard(10, true, false, 1234561);
		MSCS.getCardMap().put(smartCard.getCardNo(), smartCard);
		smartCard = new SmartCard(70, true, false, 1234562);
		MSCS.getCardMap().put(smartCard.getCardNo(), smartCard);
		smartCard = new SmartCard(50, true, false, 1234563);
		MSCS.getCardMap().put(smartCard.getCardNo(), smartCard);
		smartCard = new SmartCard(60, false, false, 1234564);
		Trip t = new Trip();
		t.setBalance(23);
		Station src = new Station();
		src.setDistanceFromRef(5);src.setFootFall(0);src.setStationCode(22);src.setStationName("station1");
		Station dest = new Station();
		dest.setDistanceFromRef(7);dest.setFootFall(0);dest.setStationCode(21);dest.setStationName("station2");
		t.setDestinationStation(dest);t.setFare(10);t.setJourneyDate(Calendar.getInstance().getTime());t.setSmartCard(smartCard);t.setSourceStation(src);t.setTripId(1003);
		MSCS.getTripMap().put(1L, t);

	}



	@Test
	public void isValidSwipeCard() {
		assertFalse(MSCS.isValidCard(1234564));
	}

	@Test
	public void isInValidSwipeCard() {
		assertTrue(MSCS.isValidCard(1234564));
	}

	@Test
	public void isEligibleForSwipe() {
		assertTrue(MSCS.isEligibleForSwipeIn(1234564));
	}

	@Test
	public void isNotEligibleForSwipe() {
		assertFalse(MSCS.isEligibleForSwipeIn(1234568l));
	}
	
	@Test
	public void isvalidTrip(){
		assertTrue(MSCS.isValidTrip(MSCS.getTripMap().get(1L)));
	}

}
